package task2;

public interface IRelationship {
	public void provoke();
	public void gift();
	public void attack();
	public void chat();
	
	public String name();
}
