public class GameTestDriver {
	public static void main(String[] args) {
		Game myGame = new Game();
		myGame.play(4, 4);
	}

}
