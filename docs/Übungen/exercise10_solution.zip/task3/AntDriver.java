public class AntDriver {

  public static void main(String[] args) {

    Ant tiggi = new Ant();
    tiggi.loadUp();

  }
}
